#ifndef _MR_COMMON
#define _MR_COMMON

#include <vector>

using namespace std;


#define MAX_FILE_PATH 1024


typedef vector< unsigned char* > PartitionList;
typedef vector< unsigned char* > LineList;


#endif
